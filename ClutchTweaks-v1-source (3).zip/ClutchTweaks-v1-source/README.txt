CLUTCHTWEAKS UTILITY v1.0 SOURCE

Windows desktop application built with WPF and .NET 8.
No command window appears because the project output type is WinExe.

CURRENT FEATURES
- Dashboard and Clutch Mode preset
- Windows Game Mode on/off
- Reduced animations on/off
- Temporary-file cleanup with preview
- System information
- Windows System Protection shortcut
- Apply/undo controls and visible status messages

RELEASE TARGET
The included Visual Studio publish profile is configured for Windows x64,
self-contained, single-file publishing. End users do not need to install .NET.

BUILD NOTE
This archive contains complete source, not a compiled executable. Open
ClutchTweaks.csproj in Visual Studio 2022, choose Publish, then select the
Windows-x64 profile. No CMD or BAT file is included.

SAFETY
Test on a spare Windows account or virtual machine before public distribution.
Code signing is recommended before selling or distributing the executable.
