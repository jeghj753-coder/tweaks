namespace ClutchTweaks.Services;
public static class CleanupService
{
    public static (long bytes, int files) CleanTemp()
    {
        long bytes = 0; int files = 0; var root = Path.GetTempPath();
        foreach (var file in Directory.EnumerateFiles(root, "*", SearchOption.TopDirectoryOnly))
        {
            try { var info = new FileInfo(file); bytes += info.Length; info.Delete(); files++; } catch { }
        }
        foreach (var dir in Directory.EnumerateDirectories(root)) { try { Directory.Delete(dir, true); } catch { } }
        return (bytes, files);
    }
}
