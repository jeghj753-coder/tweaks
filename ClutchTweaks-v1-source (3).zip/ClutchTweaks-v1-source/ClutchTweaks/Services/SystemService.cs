using Microsoft.Win32;
using System.Diagnostics;
using System.Management;
using System.Runtime.InteropServices;

namespace ClutchTweaks.Services;

public static class SystemService
{
    public static string GetWindowsName() => RuntimeInformation.OSDescription;
    public static string GetCpu() => Query("Win32_Processor", "Name");
    public static string GetGpu() => Query("Win32_VideoController", "Name");
    public static string GetRam()
    {
        var bytes = QueryLong("Win32_ComputerSystem", "TotalPhysicalMemory");
        return bytes > 0 ? $"{bytes / 1073741824d:0.#} GB" : "Unknown";
    }
    private static string Query(string cls, string property)
    {
        try { using var s = new ManagementObjectSearcher($"SELECT {property} FROM {cls}"); return s.Get().Cast<ManagementObject>().Select(x => x[property]?.ToString()).FirstOrDefault(x => !string.IsNullOrWhiteSpace(x)) ?? "Unknown"; } catch { return "Unknown"; }
    }
    private static long QueryLong(string cls, string property) => long.TryParse(Query(cls, property), out var n) ? n : 0;
    public static void OpenSettings(string uri) => Process.Start(new ProcessStartInfo(uri) { UseShellExecute = true });
    public static bool GameModeEnabled() => (Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\GameBar", "AutoGameModeEnabled", 0) as int? ?? 0) == 1;
    public static void SetGameMode(bool enabled) { using var key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\GameBar"); key.SetValue("AutoGameModeEnabled", enabled ? 1 : 0, RegistryValueKind.DWord); }
    public static bool AnimationsReduced() => (Registry.GetValue(@"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects", "VisualFXSetting", 0) as int? ?? 0) == 2;
    public static void SetReducedAnimations(bool enabled) { using var key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"); key.SetValue("VisualFXSetting", enabled ? 2 : 0, RegistryValueKind.DWord); }
}
