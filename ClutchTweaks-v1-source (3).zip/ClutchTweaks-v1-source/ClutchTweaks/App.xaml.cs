using System.Windows;
namespace ClutchTweaks;
public partial class App : Application { }
