using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using ClutchTweaks.Services;

namespace ClutchTweaks;
public partial class MainWindow : Window
{
    private static readonly Brush Card = new SolidColorBrush(Color.FromRgb(29,29,39));
    private static readonly Brush Muted = new SolidColorBrush(Color.FromRgb(151,151,168));
    public MainWindow() { InitializeComponent(); ShowDashboard(); }
    private Border Panel(string title, string description, params UIElement[] actions)
    {
        var stack = new StackPanel(); stack.Children.Add(new TextBlock { Text=title, FontSize=17, FontWeight=FontWeights.SemiBold }); stack.Children.Add(new TextBlock { Text=description, Foreground=Muted, TextWrapping=TextWrapping.Wrap, Margin=new Thickness(0,6,0,14) });
        var row = new StackPanel { Orientation=Orientation.Horizontal }; foreach (var a in actions) { if (a is FrameworkElement f) f.Margin=new Thickness(0,0,8,0); row.Children.Add(a); } stack.Children.Add(row);
        return new Border { Background=Card, CornerRadius=new CornerRadius(12), Padding=new Thickness(18), Margin=new Thickness(0,0,0,12), Child=stack };
    }
    private Button Btn(string text, RoutedEventHandler click) { var b=new Button { Content=text }; b.Click += click; return b; }
    private void Header(string title, string subtitle) { PageTitle.Text=title; PageSubtitle.Text=subtitle; ContentHost.Children.Clear(); }
    private void ShowDashboard()
    {
        Header("Dashboard", "A clean starting point for safer Windows optimization.");
        ContentHost.Children.Add(Panel("Welcome to ClutchTweaks", "This first release focuses on transparent actions that can be reviewed and reversed. No fake FPS promises and no hidden scripts.", Btn("Open Gaming", Gaming_Click), Btn("System Info", SystemInfo_Click)));
        ContentHost.Children.Add(Panel("Clutch Mode", "Recommended preset preview. Clutch Mode currently enables Windows Game Mode and reduces visual effects. You can undo both options separately.", Btn("Apply preset", ApplyPreset_Click)));
        ContentHost.Children.Add(Panel("Safety first", "Close games and save your work before changing Windows settings. Restart Windows if a setting does not appear immediately."));
    }
    private void Dashboard_Click(object s, RoutedEventArgs e)=>ShowDashboard();
    private void Gaming_Click(object? s, RoutedEventArgs e)
    {
        Header("Gaming", "Gaming-related Windows settings with clear undo controls.");
        ContentHost.Children.Add(Panel("Windows Game Mode", "Asks Windows to prioritize the gaming experience while a game is running.", Btn("Enable", (_,_)=>SetGameMode(true)), Btn("Undo", (_,_)=>SetGameMode(false)), Btn("Open Windows page", (_,_)=>SystemService.OpenSettings("ms-settings:gaming-gamemode"))));
        ContentHost.Children.Add(Panel("Graphics settings", "Open Windows graphics preferences to choose the high-performance GPU per game. ClutchTweaks does not force a value without your review.", Btn("Open graphics settings", (_,_)=>SystemService.OpenSettings("ms-settings:display-advancedgraphics"))));
    }
    private void SetGameMode(bool enabled) { try { SystemService.SetGameMode(enabled); StatusText.Text=$"Game Mode setting {(enabled?"enabled":"restored")}."; } catch(Exception ex){ StatusText.Text="Could not change Game Mode: "+ex.Message; } }
    private void Performance_Click(object? s, RoutedEventArgs e)
    {
        Header("Performance", "Simple system responsiveness options.");
        ContentHost.Children.Add(Panel("Reduce visual effects", "Uses Windows' performance preference for visual effects. Undo returns Windows to choosing visual effects automatically.", Btn("Reduce effects", (_,_)=>SetEffects(true)), Btn("Undo", (_,_)=>SetEffects(false))));
        ContentHost.Children.Add(Panel("Startup apps", "Review which apps launch with Windows. Disable only programs you recognize and do not need at startup.", Btn("Open startup apps", (_,_)=>SystemService.OpenSettings("ms-settings:startupapps"))));
        ContentHost.Children.Add(Panel("Power settings", "Open Windows power settings. This app does not force an unsupported custom power plan.", Btn("Open power settings", (_,_)=>SystemService.OpenSettings("ms-settings:powersleep"))));
    }
    private void SetEffects(bool reduce) { try { SystemService.SetReducedAnimations(reduce); StatusText.Text=reduce?"Reduced visual effects selected. Sign out or restart if needed.":"Visual effects returned to automatic selection."; } catch(Exception ex){ StatusText.Text="Could not change visual effects: "+ex.Message; } }
    private void Cleaner_Click(object? s, RoutedEventArgs e)
    {
        Header("Cleaner", "Remove temporary files Windows and apps are no longer using.");
        ContentHost.Children.Add(Panel("User temporary files", "Attempts to delete files in your Windows temporary directory. Files currently in use are safely skipped.", Btn("Clean temporary files", CleanTemp_Click)));
        ContentHost.Children.Add(Panel("Windows Storage", "Open Windows' built-in Storage page for a detailed review before deleting larger categories.", Btn("Open Storage", (_,_)=>SystemService.OpenSettings("ms-settings:storagesense"))));
    }
    private void CleanTemp_Click(object s, RoutedEventArgs e) { try { var r=CleanupService.CleanTemp(); StatusText.Text=$"Cleanup complete: {r.files} files, {r.bytes/1048576d:0.0} MB removed. Locked files were skipped."; } catch(Exception ex){ StatusText.Text="Cleanup stopped: "+ex.Message; } }
    private void SystemInfo_Click(object? s, RoutedEventArgs e)
    {
        Header("System Info", "A quick summary of this PC.");
        ContentHost.Children.Add(Panel("Operating system", SystemService.GetWindowsName())); ContentHost.Children.Add(Panel("Processor", SystemService.GetCpu())); ContentHost.Children.Add(Panel("Graphics", SystemService.GetGpu())); ContentHost.Children.Add(Panel("Memory", SystemService.GetRam()));
    }
    private void Settings_Click(object? s, RoutedEventArgs e) { Header("Settings", "Application information and support."); ContentHost.Children.Add(Panel("ClutchTweaks Utility v1.0", "Initial public foundation build. Settings are applied locally and the utility does not collect account credentials.")); ContentHost.Children.Add(Panel("Windows restore", "Open Windows System Protection to create or use a restore point before wider system changes.", Btn("Open System Protection", (_,_)=>SystemService.OpenSettings("systempropertiesprotection")))); }
    private void ApplyPreset_Click(object s, RoutedEventArgs e) { try { SystemService.SetGameMode(true); SystemService.SetReducedAnimations(true); StatusText.Text="Clutch Mode applied: Game Mode enabled and visual effects reduced."; } catch(Exception ex){ StatusText.Text="Preset stopped: "+ex.Message; } }
}
